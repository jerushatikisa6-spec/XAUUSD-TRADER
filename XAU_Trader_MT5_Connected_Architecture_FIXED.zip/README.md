# XAU Trader — MT5 Connected Architecture

This package contains a production-oriented starter architecture:

Android App <-> HTTPS API Bridge <-> MT5 Expert Advisor <-> Broker

## Components

1. `android/` — Android controller app starter.
2. `bridge/` — Node.js/Express API bridge with in-memory state for development.
3. `mt5/XAUTraderBridgeEA.mq5` — MT5 EA that polls the bridge for commands and posts status.

## Security

Before real-money use:
- Put the bridge behind HTTPS.
- Use a strong per-device/API token.
- Never put broker passwords in the Android app.
- Add server-side authentication/authorization.
- Add command IDs and idempotency.
- Store secrets in environment variables.
- Add audit logs.
- Run the bridge and MT5 on a secured VPS.
- Test exclusively on a demo account first.

## MT5 setup

1. Run the bridge on a VPS.
2. Set `BRIDGE_TOKEN` in the bridge.
3. In MT5: Tools -> Options -> Expert Advisors -> enable WebRequest.
4. Add the bridge URL, e.g. `https://YOUR-DOMAIN`.
5. Attach the EA to XAUUSD M15.
6. Set the EA's `BridgeBaseUrl` and `ApiToken`.
7. The EA polls `/api/v1/commands/next` and reports to `/api/v1/status`.

## Development

Bridge:
    cd bridge
    npm install
    npm start

The Android app currently uses the bridge URL configured in `ApiConfig.kt`.
For a real deployment, replace the development URL with your HTTPS domain.

## Important

The bridge is intentionally simple and uses in-memory state. It is NOT production-ready as a financial backend. Add a persistent database, authentication, TLS, rate limiting, audit logging, and robust command processing before live trading.
