import express from "express";
import crypto from "crypto";

const app = express();
app.use(express.json({ limit: "32kb" }));

const PORT = Number(process.env.PORT || 8080);
const TOKEN = process.env.BRIDGE_TOKEN || "CHANGE_ME";
const state = {
  mt5: { online: false, updatedAt: null },
  account: {},
  positions: [],
  queue: []
};

function auth(req, res, next) {
  const supplied = req.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!supplied || supplied !== TOKEN) return res.status(401).json({ error: "unauthorized" });
  next();
}

app.get("/health", (_, res) => res.json({ ok: true }));

app.get("/api/v1/status", auth, (_, res) => {
  res.json(state);
});

app.post("/api/v1/status", auth, (req, res) => {
  state.mt5 = {
    online: true,
    updatedAt: new Date().toISOString()
  };
  state.account = req.body.account || {};
  state.positions = Array.isArray(req.body.positions) ? req.body.positions : [];
  res.json({ ok: true });
});

app.get("/api/v1/commands/next", auth, (_, res) => {
  const command = state.queue.shift() || null;
  res.json(command || { id: null, type: "NONE" });
});

app.post("/api/v1/commands", auth, (req, res) => {
  const allowed = new Set(["START", "STOP", "CLOSE_ALL", "SET_RISK", "ALLOW_BUY", "ALLOW_SELL"]);
  const type = String(req.body.type || "");
  if (!allowed.has(type)) return res.status(400).json({ error: "unsupported command" });

  const command = {
    id: crypto.randomUUID(),
    type,
    value: req.body.value ?? null,
    createdAt: new Date().toISOString()
  };
  state.queue.push(command);
  res.status(202).json(command);
});

app.listen(PORT, () => {
  console.log(`XAU Trader bridge listening on ${PORT}`);
});
