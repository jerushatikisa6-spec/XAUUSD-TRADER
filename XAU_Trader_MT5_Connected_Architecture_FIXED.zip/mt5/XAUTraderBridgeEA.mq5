//+------------------------------------------------------------------+
//| XAUTraderBridgeEA.mq5                                            |
//| Bridge controller for XAU Trader Android app                     |
//+------------------------------------------------------------------+
#property strict
#property version "1.00"

#include <Trade/Trade.mqh>
CTrade trade;

input string BridgeBaseUrl = "https://YOUR-DOMAIN";
input string ApiToken = "CHANGE_ME";
input int PollSeconds = 3;
input ulong MagicNumber = 20261006;

bool RobotEnabled = false;
bool AllowBuy = true;
bool AllowSell = true;
double RiskPercent = 1.0;
string LastCommandId = "";

int OnInit()
{
   trade.SetExpertMagicNumber(MagicNumber);
   EventSetTimer(MathMax(1, PollSeconds));
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   ProcessCommand();
   PublishStatus();
}

void OnTick()
{
   // Your existing XAUUSD strategy can remain here.
   // Gate all new entries with RobotEnabled, AllowBuy, AllowSell.
}

string Headers()
{
   return "Content-Type: application/json\r\nAuthorization: Bearer " + ApiToken + "\r\n";
}

bool HttpGet(string url, string &response)
{
   char data[], result[];
   string resultHeaders;
   int code = WebRequest("GET", url, Headers(), 5000, data, result, resultHeaders);
   if(code < 200 || code >= 300) return false;
   response = CharArrayToString(result);
   return true;
}

bool HttpPost(string url, string body, string &response)
{
   char data[], result[];
   string resultHeaders;
   StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   int code = WebRequest("POST", url, Headers(), 5000, data, result, resultHeaders);
   if(code < 200 || code >= 300) return false;
   response = CharArrayToString(result);
   return true;
}

void ProcessCommand()
{
   string response;
   if(!HttpGet(BridgeBaseUrl + "/api/v1/commands/next", response))
      return;

   string id = JsonString(response, "id");
   string type = JsonString(response, "type");
   if(id == "" || id == "null" || type == "NONE") return;
   if(id == LastCommandId) return;
   LastCommandId = id;

   if(type == "START") RobotEnabled = true;
   else if(type == "STOP") RobotEnabled = false;
   else if(type == "ALLOW_BUY") AllowBuy = JsonBool(response, "value");
   else if(type == "ALLOW_SELL") AllowSell = JsonBool(response, "value");
   else if(type == "SET_RISK") RiskPercent = JsonNumber(response, "value");
   else if(type == "CLOSE_ALL") CloseAllOurPositions();
}

void PublishStatus()
{
   string body = "{\"account\":{\"balance\":" +
                 DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE), 2) +
                 ",\"equity\":" +
                 DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) +
                 "},\"positions\":[]}";

   string response;
   HttpPost(BridgeBaseUrl + "/api/v1/status", body, response);
}

void CloseAllOurPositions()
{
   for(int i=PositionsTotal()-1; i>=0; i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0) continue;

      if(PositionGetString(POSITION_SYMBOL)==_Symbol &&
         (ulong)PositionGetInteger(POSITION_MAGIC)==MagicNumber)
         trade.PositionClose(ticket);
   }
}

// Minimal JSON helpers for the known bridge payload.
// For production, use a robust JSON parser/serializer.
string JsonString(string json, string key)
{
   string needle="\"" + key + "\":\"";
   int p=StringFind(json, needle);
   if(p<0) return "";
   p += StringLen(needle);
   int e=StringFind(json, "\"", p);
   if(e<0) return "";
   return StringSubstr(json,p,e-p);
}

double JsonNumber(string json, string key)
{
   string needle="\"" + key + "\":";
   int p=StringFind(json,needle);
   if(p<0) return 0;
   p += StringLen(needle);
   int e=p;
   while(e<StringLen(json))
   {
      ushort c=StringGetCharacter(json,e);
      if((c>='0'&&c<='9') || c=='.' || c=='-') e++;
      else break;
   }
   return StringToDouble(StringSubstr(json,p,e-p));
}

bool JsonBool(string json, string key)
{
   string needle="\"" + key + "\":";
   int p=StringFind(json,needle);
   if(p<0) return false;
   p += StringLen(needle);
   return StringSubstr(json,p,4)=="true";
}
