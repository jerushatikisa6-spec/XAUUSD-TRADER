package com.example.xautrader

object ApiConfig {
    // Replace with your HTTPS bridge domain.
    const val BASE_URL = "https://YOUR-DOMAIN"
    // Do not commit a production token to source control.
}
