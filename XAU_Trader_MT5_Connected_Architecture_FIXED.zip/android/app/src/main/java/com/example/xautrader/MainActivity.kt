package com.example.xautrader

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        root.addView(TextView(this).apply {
            text = "XAU TRADER"
            textSize = 28f
        })

        status = TextView(this).apply {
            text = "MT5: checking..."
            textSize = 18f
        }
        root.addView(status)

        val start = Button(this).apply {
            text = "START ROBOT"
            setOnClickListener { sendCommand("START") }
        }
        root.addView(start)

        val stop = Button(this).apply {
            text = "STOP ROBOT"
            setOnClickListener { sendCommand("STOP") }
        }
        root.addView(stop)

        val close = Button(this).apply {
            text = "EMERGENCY CLOSE"
            setOnClickListener { sendCommand("CLOSE_ALL") }
        }
        root.addView(close)

        val refresh = Button(this).apply {
            text = "REFRESH STATUS"
            setOnClickListener { refreshStatus() }
        }
        root.addView(refresh)

        setContentView(root)
        refreshStatus()
    }

    private fun sendCommand(type: String) {
        Thread {
            try {
                val url = URL("${ApiConfig.BASE_URL}/api/v1/commands")
                val c = url.openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer REPLACE_WITH_SECURE_TOKEN")
                c.outputStream.use { it.write("""{"type":"$type"}""".toByteArray()) }
                val code = c.responseCode
                runOnUiThread { status.text = "Command $type: HTTP $code" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Connection error: ${e.message}" }
            }
        }.start()
    }

    private fun refreshStatus() {
        Thread {
            try {
                val url = URL("${ApiConfig.BASE_URL}/api/v1/status")
                val c = url.openConnection() as HttpURLConnection
                c.setRequestProperty("Authorization", "Bearer REPLACE_WITH_SECURE_TOKEN")
                val text = c.inputStream.bufferedReader().readText()
                runOnUiThread { status.text = text }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Offline / not configured" }
            }
        }.start()
    }
}
